package com.mygdx.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.Pixmap.Format;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.scenes.scene2d.ui.Label.LabelStyle;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton.TextButtonStyle;
import com.badlogic.gdx.scenes.scene2d.ui.CheckBox.CheckBoxStyle;
import com.badlogic.gdx.scenes.scene2d.ui.TextField.TextFieldStyle;
import com.badlogic.gdx.scenes.scene2d.ui.TextField.TextFieldListener;
import com.badlogic.gdx.scenes.scene2d.ui.Tree.TreeStyle;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import faltkullen.*;

import java.util.ArrayList;

public class MyGdxGame extends ApplicationAdapter {
    boolean MOUSE_PAN = true;

    SpriteBatch batch;
	Texture img;
    Stage stage;
    Skin skin;
    OrthographicCamera cam;
    int width, height;
    int centerLineY, centerLineX;
    CustomSprite selected;
    ArrayList<CustomSprite> sprites;

    private ValuesGroup values;
    private WidgetGroup composition;
    private EvolutionGroup evolution;
    private OrganogramGroup organogram;
    private WidgetGroup focusGroup;

    private Main main;
    private Label battlesSimulated;
    private Label generationsCompleted;
    private Texture redTeam, blueTeam;
    private TestOfMap battlefield;

    private WidgetGroup under;
    private WidgetGroup normalUnder;
    private OrganogramUnder organogramUnder;

    private Leader redLeader, blueLeader;
	
	@Override
	public void create () {
        main = new Main(this);
        sprites = new ArrayList<CustomSprite>();
        width = Gdx.graphics.getWidth();
        height = Gdx.graphics.getHeight();

        centerLineY = Gdx.graphics.getHeight()/2;
        centerLineX = Gdx.graphics.getWidth()/2;
        cam = new OrthographicCamera(width, height);
        cam.position.set(cam.viewportWidth / 2f, cam.viewportHeight / 2f, 0);
        cam.update();

        batch = new SpriteBatch();
        /*
		img = new Texture("spintest.png");
        CustomSprite sprite = new CustomSprite(img, 0);
        sprite.setCoords(width / 2, height / 2);
        sprites.add(sprite);
        selected = sprite;
        sprite = new CustomSprite(img, 1);
        sprite.setCoords(width / 2 + 200, height / 2);
        sprites.add(sprite);
        sprite = new CustomSprite(img, 2);
        sprite.setCoords(width / 2 - 200, height / 2);
        sprites.add(sprite);
        */
        stage = new Stage();
        Gdx.input.setInputProcessor(stage);

        // A skin can be loaded via JSON or defined programmatically, either is fine. Using a skin is optional but strongly
        // recommended solely for the convenience of getting a texture, region, etc as a drawable, tinted drawable, etc.
        skin = new Skin();

        // Generate a 1x1 white texture and store it in the skin named "white".
        Pixmap pixmap = new Pixmap(1, 1, Format.RGBA8888);
        pixmap.setColor(Color.WHITE);
        pixmap.fill();
        skin.add("white", new Texture(pixmap));

        pixmap = new Pixmap(3, 3, Format.RGBA8888);
        pixmap.setColor(Color.RED);
        pixmap.fill();
        redTeam = new Texture(pixmap);
        pixmap.setColor(Color.BLUE);
        pixmap.fill();
        blueTeam = new Texture(pixmap);

        pixmap = new Pixmap(1, 7, Format.RGBA8888);
        pixmap.setColor(Color.WHITE);
        pixmap.fill();
        skin.add("selection", new Texture(pixmap));

        Texture tex = new Texture("checkboxEmpty.png");
        skin.add("checkboxOff", tex);
        tex = new Texture("checkboxChecked.png");
        skin.add("checkboxOn", tex);
        String[] strs = new String[]{"buttonUp", "buttonDown", "buttonOver", "start", "stop", "plus", "minus", "wideButtonUp", "wideButtonDown"};
        for(int a=0;a<strs.length;a++){
            tex = new Texture(strs[a]+".png");
            skin.add(strs[a], tex);
        }

        // Store the default libgdx font under the name "default".
        skin.add("default", new BitmapFont());

        // Configure a TextButtonStyle and name it "default". Skin resources are stored by type, so this doesn't overwrite the font.
        TextButtonStyle textButtonStyle = new TextButtonStyle();
        textButtonStyle.up = skin.newDrawable("white", Color.DARK_GRAY);
        textButtonStyle.down = skin.newDrawable("white", Color.DARK_GRAY);
        textButtonStyle.over = skin.newDrawable("white", Color.LIGHT_GRAY);
        textButtonStyle.font = skin.getFont("default");
        skin.add("default", textButtonStyle);

        //Start/Stop Button
        textButtonStyle = new TextButtonStyle();
        textButtonStyle.up = skin.getDrawable("buttonUp");
        textButtonStyle.down = skin.getDrawable("buttonDown");
        textButtonStyle.over = skin.getDrawable("buttonOver");
        textButtonStyle.font = skin.getFont("default");
        textButtonStyle.fontColor = Color.BLACK;
        skin.add("button", textButtonStyle);

        final LabelStyle playStyle = new LabelStyle();
        playStyle.background = skin.getDrawable("start");
        playStyle.font = skin.getFont("default");
        playStyle.fontColor = Color.BLACK;
        skin.add("play", playStyle);

        final LabelStyle stopStyle = new LabelStyle();
        stopStyle.background = skin.getDrawable("stop");
        stopStyle.font = skin.getFont("default");
        stopStyle.fontColor = Color.BLACK;
        skin.add("stop", stopStyle);

        // Configure a TextButtonStyle and name it "default". Skin resources are stored by type, so this doesn't overwrite the font.
        TextFieldStyle textFieldStyle = new TextFieldStyle();
        textFieldStyle.background = skin.newDrawable("white", Color.BLACK);
        textFieldStyle.fontColor = Color.WHITE;
        textFieldStyle.font = skin.getFont("default");
        textFieldStyle.focusedBackground = skin.newDrawable("white", Color.DARK_GRAY);
        textFieldStyle.selection = skin.newDrawable("selection");
        skin.add("default", textFieldStyle);

        // Configure a LabelStyle and name it "default". Skin resources are stored by type, so this doesn't overwrite the font.
        LabelStyle labelStyle = new LabelStyle();
        //labelStyle.background = skin.newDrawable("white", Color.WHITE);
        labelStyle.fontColor = Color.WHITE;
        labelStyle.font = skin.getFont("default");
        skin.add("default", labelStyle);

        labelStyle = new LabelStyle();
        labelStyle.fontColor = Color.BLACK;
        labelStyle.font = skin.getFont("default");
        skin.add("black", labelStyle);

        CheckBoxStyle checkStyle = new CheckBoxStyle();
        checkStyle.font = skin.getFont("default");
        checkStyle.fontColor = Color.BLACK;
        checkStyle.checkboxOff = skin.getDrawable("checkboxOff");
        checkStyle.checkboxOn = skin.getDrawable("checkboxOn");
        skin.add("default", checkStyle);

        TreeStyle treeStyle = new TreeStyle();
        treeStyle.plus = skin.getDrawable("plus");
        treeStyle.minus = skin.getDrawable("minus");
        skin.add("default", treeStyle);

        createUnder();

        // We create a panel for our UI where we can place buttons and the like
        // We should probably do something like have a table or other Group-widget here to ease the changing of the buttons

        // Add an image actor. Have to set the size, else it would be the size of the drawable (which is the 1x1 texture).
        Image panel = new Image(skin.newDrawable("white", Color.WHITE));
        panel.setSize(100f, Gdx.graphics.getHeight());
        stage.addActor(panel);

        panel = new Image(skin.newDrawable("white", Color.WHITE));
        panel.setSize(width - 100, 25);
        panel.setPosition(100, height-25);
        stage.addActor(panel);

        panel = new Image(skin.newDrawable("white", Color.WHITE));
        panel.setSize(width - 100, 200);
        panel.setPosition(100, 0);
        stage.addActor(panel);

        String[] overheadButtonStrings = new String[]{"Army Settings", "Army Composition", "Organogram", "Map", "Evolution Settings"};
        final TextButton[] overheadButtons = new TextButton[overheadButtonStrings.length];
        for(int a=0;a<overheadButtonStrings.length;a++){
            TextButton tb = new TextButton(overheadButtonStrings[a], skin, "button");
            tb.setPosition(25.0f + 160*a, height - 25);
            tb.setSize(150, 25);
            stage.addActor(tb);
            overheadButtons[a] = tb;
        }
        ChangeListener listen = new ChangeListener() {
            public void changed(ChangeEvent event, Actor actor) {
                if (focusGroup != null) {
                    focusGroup.remove();
                    focusGroup = null;
                }
                if (actor == overheadButtons[0]) {
                    focusGroup = values;
                } else if (actor == overheadButtons[1]) {
                    focusGroup = composition;
                } else if (actor == overheadButtons[2]) {
                    focusGroup = organogram;
                    organogram.loadCommand(redLeader);
                    under.remove();
                } else if (actor == overheadButtons[3]){
                    focusGroup = null;
                } else if (actor == overheadButtons[4]){
                    focusGroup = evolution;
                }
                if(focusGroup != null){
                    stage.addActor(focusGroup);
                    if(focusGroup != organogram && under != normalUnder){
                        under.remove();
                        under = normalUnder;
                        stage.addActor(under);
                    }
                    else if(focusGroup == organogram && under != organogramUnder){
                        under.remove();
                        under = organogramUnder;
                        stage.addActor(under);
                    }
                }
                else if(under != normalUnder){
                    under.remove();
                    under = normalUnder;
                    stage.addActor(under);
                }
            }
        };
        for(int a=0;a<overheadButtons.length;a++){
            overheadButtons[a].addListener(listen);
        }

        /*
        TextButton openValues = new TextButton("Values", skin);
        openValues.setPosition(25.0f, height - 25);
        stage.addActor(openValues);
        openValues.addListener(new ChangeListener() {
            public void changed(ChangeEvent event, Actor actor) {
                if(focusGroup != null){
                    focusGroup.remove();
                }
                focusGroup = values;
                stage.addActor(focusGroup);
            }
        });
        */

        float valuesHeight = height - 225;
        float valuesWidth = width - 100;
        values = new ValuesGroup(skin, valuesWidth, valuesHeight);

        /*
        for(int a=0;a<10;a++){
            for(int b=0;b<10;b++){
                Label l = new Label(""+a+"/"+b, skin);
                l.setPosition(25*a, 25*b);
                values.addActor(l);
            }
        }
        */
        values.setPosition(100, 200);
        //values.generateComponents234();

        evolution = new EvolutionGroup(skin, valuesWidth, valuesHeight);
        evolution.setPosition(100, 200);

        organogramUnder = new OrganogramUnder(skin);
        organogramUnder.setPosition(100, 0);
        organogramUnder.setSize(width - 100, 200);

        organogram = new OrganogramGroup(skin, valuesWidth, valuesHeight, organogramUnder);
        organogram.setPosition(100, 200);
        organogramUnder.organogram = organogram;

        battlesSimulated = new Label("Battles simualted : 0", skin, "black");
        battlesSimulated.setPosition(0, 0);
        battlesSimulated.setSize(200, 15);
        stage.addActor(battlesSimulated);

        generationsCompleted = new Label("Generations completed : 0", skin, "black");
        generationsCompleted.setPosition(0, 15);
        generationsCompleted.setSize(200, 15);
        stage.addActor(generationsCompleted);

        redLeader = new Leader(0, false);
        redLeader.name = "Number 1";
        int num = 1;
        for(int a=0;a<3;a++){
            num++;
            Leader l = new Leader(0, false);
            redLeader.commands.add(l);
            l.commandedBy = redLeader;
            l.name = "Number " + num;
            for(int b=0;b<3;b++){
                num++;
                Leader l2 = new Leader(0, false);
                l.commands.add(l2);
                l2.commandedBy = redLeader;
                l2.name = "Number " + num;
            }
        }

        blueLeader = new Leader(0, false);
        blueLeader.name = "Blue Leader";

        createArmyButtons();
    }

    boolean mouseDown = false;

    public void handleInput(){
        if(!mouseDown && Gdx.input.isTouched()){
            mouseDown = true;
        }
        else if(mouseDown && !Gdx.input.isTouched()){
            //A click has been made
            mouseDown = false;
            //Where was the click?
            int x = Gdx.input.getX();
            //x += cam.position.x - width;
            int y = height - Gdx.input.getY();
            //y += cam.position.y - height;
            System.out.println("x = " + x);
            System.out.println("y = " + y);
        }
        /**
         * Zooming
         */

        //Zoom out
        if(Gdx.input.isKeyPressed(Input.Keys.X)) {
            cam.zoom += 0.3;
        }
        //Zoom in
        if(Gdx.input.isKeyPressed(Input.Keys.Z)) {
            if(cam.zoom >= 1) { //So we don't zoom too muc.
                cam.zoom -= 0.3;
            }
        }
        //Zoom in and out faster
        if(Gdx.input.isKeyPressed(Input.Keys.X) && Gdx.input.isKeyPressed(Input.Keys.SHIFT_LEFT)) {
            cam.zoom += 0.6;
        }
        if(Gdx.input.isKeyPressed(Input.Keys.Z) && Gdx.input.isKeyPressed(Input.Keys.SHIFT_LEFT)) {
            if (cam.zoom >= 1) {
                cam.zoom -= 0.6;
            }
        }

        /**
         * Moving the camera using keyboard.
         */

        if(Gdx.input.isKeyPressed(Input.Keys.LEFT)) {
            cam.translate(-3 - cam.zoom/2, 0, 0);
        }
        if(Gdx.input.isKeyPressed(Input.Keys.RIGHT)) {
            cam.translate(3 + cam.zoom/2, 0, 0);
        }
        if(Gdx.input.isKeyPressed(Input.Keys.UP)) {
            cam.translate(0, 3 + cam.zoom/2, 0);
        }
        if(Gdx.input.isKeyPressed(Input.Keys.DOWN)) {
            cam.translate(0, -3 - cam.zoom/2, 0);
        }

        if(Gdx.input.isKeyPressed(Input.Keys.LEFT) && Gdx.input.isKeyPressed(Input.Keys.SHIFT_LEFT)) {
            cam.translate(-6, 0, 0);
        }
        if(Gdx.input.isKeyPressed(Input.Keys.RIGHT) && Gdx.input.isKeyPressed(Input.Keys.SHIFT_LEFT)) {
            cam.translate(6, 0, 0);
        }
        if(Gdx.input.isKeyPressed(Input.Keys.UP) && Gdx.input.isKeyPressed(Input.Keys.SHIFT_LEFT)) {
            cam.translate(0, 6, 0);
        }
        if(Gdx.input.isKeyPressed(Input.Keys.DOWN) && Gdx.input.isKeyPressed(Input.Keys.SHIFT_LEFT)) {
            cam.translate(0, -6, 0);
        }

        /**
         * Panning the camera using the mouse.
         */
        if(MOUSE_PAN) {
            if(Gdx.input.getX() < centerLineX-0.65*centerLineX) {
                //Left
                cam.translate(-1-cam.zoom/2, 0, 0);
            }
            if(Gdx.input.getX() > centerLineX+0.65*centerLineX) {
                //Right
                cam.translate(1+cam.zoom/2, 0, 0);
            }
            if(Gdx.input.getY() < centerLineY-0.65*centerLineY) {
                //Up
                cam.translate(0, 1+cam.zoom/2, 0);
            }
            if(Gdx.input.getY() > centerLineY+0.65*centerLineY) {
                //Down
                cam.translate(0, -1-cam.zoom/2, 0);
            }

        }

        if(Gdx.input.isKeyJustPressed(Input.Keys.C)) {
            if(MOUSE_PAN) {
                System.out.println("MOUSE PAN WAS: " + MOUSE_PAN);
                MOUSE_PAN = false;
            } else {
                System.out.println("MOUSE PAN WAS: " + MOUSE_PAN);
                MOUSE_PAN = true;
            }
        }
    }

	@Override
	public void render () {
        float dt = Gdx.graphics.getDeltaTime();
        handleInput();
        cam.update();
        batch.setProjectionMatrix(cam.combined);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		Gdx.gl.glClearColor(0.25f, 0.25f, 0.25f, 1);
		batch.begin();
		//batch.draw(img, Gdx.graphics.getWidth()/2 - size/2 + MathUtils.cos(angleRad) * radius, Gdx.graphics.getHeight()/2 - size/2 + MathUtils.sin(angleRad) * radius, size, size);
        //batch.draw(sprite, Gdx.graphics.getWidth()/2 - size/2 + MathUtils.cos(angleRad) * radius, Gdx.graphics.getHeight()/2 - size/2 + MathUtils.sin(angleRad) * radius, size, size);
        //sprite.update(Gdx.graphics.getDeltaTime());
        //sprite.draw(batch);
        /*
        for(CustomSprite sprite : sprites){
            sprite.update(dt);
            sprite.draw(batch);
        }
        */
        if(battlefield != null) {
            System.out.println("Drawing units");
            ArrayList<Army> armies = battlefield.fetchArmies();
            for (int a = 0; a < armies.size(); a++) {
                ArrayList<Unit> units = armies.get(a).units;
                System.out.println("Units size = " + units.size());
                for (int b = 0; b < units.size(); b++) {
                    Unit u = units.get(b);
                    if (u.alive) {
                        Position p = u.getPosition();
                        Texture imgdraw = redTeam;
                        if (a == 1) {
                            imgdraw = blueTeam;
                        }
                        batch.draw(imgdraw, (float) p.x - 1 + 100, (float) p.y - 1 + 200, 3, 3);
                    }
                }
            }
        }
		batch.end();

        stage.act(Math.min(Gdx.graphics.getDeltaTime(), 1 / 30f));
        stage.draw();
	}

    @Override
    public void dispose(){
        stage.dispose();
        skin.dispose();
    }

    public void updateBattlesSimulated(int s){
        battlesSimulated.setText("Battles simulated : " + s);
    }

    public void updateGenerationsCompleted(int a){
        generationsCompleted.setText("Generations completed : " + a);
    }

    public void setMap(TestOfMap t){
        battlefield = t;
    }

    private void createUnder(){
        under = new WidgetGroup();
        under.setSize(width - 100, 200);
        under.setPosition(100, 0);

        final TextButton play = new TextButton("Play", skin, "button");
        play.setPosition(375, 50);
        under.addActor(play);
        play.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                if (play.isChecked()) {
                    if (main.startNew) {
                        //Start the big boy process
                        System.out.println("GO");
                        main.setEvolutionValues(evolution.getValues());
                        main.startEvolutionThread(values.getSettings(main));
                    } else {
                        System.out.println("Unpausing");
                        main.unpauseThreads();
                    }
                    play.setText("Stop");
                } else {
                    main.pauseThreads();
                    play.setText("Resume");
                }
            }
        });

        stage.addActor(under);

        normalUnder = under;
    }

    private void createArmyButtons(){
        TextButtonStyle buttonStyle = new TextButtonStyle();
        buttonStyle.up = skin.newDrawable("wideButtonUp", Color.RED);
        buttonStyle.down = skin.newDrawable("wideButtonDown", Color.RED);
        buttonStyle.font = skin.getFont("default");
        buttonStyle.fontColor = Color.BLACK;
        skin.add("redWide", buttonStyle);

        TextButton tb = new TextButton("Red Team", skin, "redWide");
        tb.setPosition(5, height - 90);
        tb.setSize(90, 40);
        tb.addListener(new ChangeListener(){
            @Override
            public void changed(ChangeEvent event, Actor actor){
                if(focusGroup == organogram){
                    organogram.loadCommand(redLeader);
                }
            }
        });
        stage.addActor(tb);

        buttonStyle = new TextButtonStyle();
        buttonStyle.up = skin.newDrawable("wideButtonUp", Color.BLUE);
        buttonStyle.down = skin.newDrawable("wideButtonDown", Color.BLUE);
        buttonStyle.font = skin.getFont("default");
        buttonStyle.fontColor = Color.BLACK;
        skin.add("blueWide", buttonStyle);

        tb = new TextButton("Blue Team", skin, "blueWide");
        tb.setPosition(5, height - 130);
        tb.setSize(90, 40);
        tb.addListener(new ChangeListener(){
            @Override
            public void changed(ChangeEvent event, Actor actor){
                if(focusGroup == organogram){
                    organogram.loadCommand(blueLeader);
                }
            }
        });
        stage.addActor(tb);
    }
}
