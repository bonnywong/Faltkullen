package com.mygdx.game;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.TextField;
import faltkullen.Attribute;
import faltkullen.Main;
import faltkullen.Settings;

/**
 * Created by Anton on 2015-08-23.
 */
public class ValuesGroup extends WidgetGroup {
    private Label[] labels;
    private TextField[][] textFields;
    private CheckBox[] boxes;

    private String[] attributeNames;
    private String[] minimumValues;
    private String[] baseValues;
    private String[] maximumValues;
    private String[] evolutionCosts;

    private Skin skin;
    private float width, height;

    public ValuesGroup(Skin sk, float w, float h){
        super();
        skin = sk;
        width = w;
        height = h;

        Image panel = new Image(skin.newDrawable("white", Color.DARK_GRAY));
        panel.setSize(width, height);
        addActor(panel);

        loadSoldierValues();

        String[] labelStrings = new String[]{"Minumum Value", "Base Value", "Maximum Value", "Evolutionary Cost"};
        for(int a=0;a<labelStrings.length;a++){
            Label l = new Label(labelStrings[a], skin);
            l.setPosition(25 + 125 * (a + 1), height - 50);
            addActor(l);
        }
        generateComponents();
    }

    public void generateComponents(){
        labels = new Label[attributeNames.length];
        textFields = new TextField[labels.length][4];
        boxes = new CheckBox[attributeNames.length];
        for(int a=0;a<labels.length;a++) {
            float h = height - 75 - 25 * a;

            Label l = new Label(attributeNames[a], skin);
            l.setPosition(5, h);
            addActor(l);
            labels[a] = l;

            CheckBox c = new CheckBox("", skin);
            c.setPosition(130, h);
            addActor(c);
            boxes[a] = c;

            String[] values = new String[]{minimumValues[a], baseValues[a], maximumValues[a], evolutionCosts[a]};
            for (int b = 0; b < 4; b++) {

                TextField t = new TextField(""+values[b], skin);
                t.setPosition(25 + 125 * (b + 1), h);
                addActor(t);
                textFields[a][b] = t;
            }
        }
        System.out.println("Textfields.length = " + textFields.length);
    }

    public Settings getSettings(Main m){
        Settings s = new Settings(m);
        for(int a=0;a<textFields.length;a++){
            int[] values = new int[4];
            String[] inCaseOfError = new String[]{minimumValues[a], baseValues[a], maximumValues[a], evolutionCosts[a]};
            for(int b=0;b<4;b++){
                try{
                    values[b] = Integer.parseInt(textFields[a][b].getText());
                }
                catch(NumberFormatException e){
                    values[b] = Integer.parseInt(inCaseOfError[b]);
                    textFields[a][b].setText(""+inCaseOfError[b]);
                }
            }
            //Name, base, min, max, cost, Settings
            Attribute att = new Attribute(attributeNames[a],
                    values[1],
                    values[0],
                    values[2],
                    values[3],
                    s);
            s.attributes.add(att);
            if(boxes[a].isChecked()){
                att.allowsChange = true;
                s.changeableAttributes.add(att);
            }
        }
        s.maxCost = s.getTotalCost();
        return s;
    }

    public void loadSoldierValues(){
        attributeNames = new String[]{"Weapon Damage",
                "Weapon Accuracy",
                "Weapon Range",
                "Protection",
                "Sensor Range",
                "Sensor Interval",
                "Soldier Accuracy",
                "Soldier Morale",
                "Soldier Movespeed"};
        minimumValues = new String[]{"1", "90", "10", "5", "5", "1", "1", "70", "1"};
        baseValues = new String[]{"75", "95", "60", "10", "100", "10", "25", "100", "5"};
        maximumValues = new String[]{"115", "100", "100", "15", "300", "20", "100", "100", "10"};
        evolutionCosts = new String[]{"100", "100", "80", "100", "225", "-75", "125", "25", "75"};
    }
}
