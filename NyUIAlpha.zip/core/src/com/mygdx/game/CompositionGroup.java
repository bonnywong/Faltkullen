package com.mygdx.game;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.utils.Array;
import faltkullen.ArmyComposition;
import faltkullen.*;

import java.util.ArrayList;

/**
 * Created by Anton on 2015-08-24.
 */
public class CompositionGroup extends WidgetGroup {
    private Skin skin;
    private float width, height;
    private ArrayList<TextField> names;
    private ArrayList<SelectBox> types;
    private ArrayList<TextField> amounts;
    private ArrayList<SelectBox> leaders;

    private ArmyComposition current;
    private float[] sizes;
    private float[] xPositions;

    public CompositionGroup(Skin sk, float w, float h) {
        super();
        skin = sk;
        width = w;
        height = h;
        sizes = new float[]{100, 75, 140, 85};
        xPositions = new float[sizes.length];
        float currentX = 5;
        xPositions[0] = currentX;
        for(int a=1;a<sizes.length;a++){
            xPositions[a] = xPositions[a-1] + sizes[a-1];
        }

        Image panel = new Image(skin.newDrawable("white", Color.DARK_GRAY));
        panel.setSize(width, height);
        addActor(panel);

        TextButton tb = new TextButton("New Unit", skin, "button");
        tb.setPosition(5, height - 30);
        tb.setSize(75, 25);
        addActor(tb);

        String[] names = new String[]{"Group Name", "Type", "Amount of Units", "Leader"};
        for(int a=0;a<names.length;a++){
            Label l = new Label(names[a], skin);
            l.setPosition(xPositions[a], height - 65);
            l.setSize(sizes[a], 25);
            addActor(l);
        }
    }

    public void loadComposition(ArmyComposition ac){
        Array<Leader> leaderList = ac.leader.getLeaderList();
        current = ac;
        for(int a=0;a<ac.groups.size();a++){
            final Group g = ac.groups.get(a);
            float h = height - 65 - 30*(a*1);
            final TextField tf = new TextField(g.name, skin);
            tf.setPosition(xPositions[a], h);
            tf.setSize(sizes[a], 25);
            tf.addListener(new ChangeListener() {
                public void changed(ChangeEvent event, Actor actor){
                    g.name = tf.getText();
                }
            });
            addActor(tf);
            names.add(tf);
        }
    }
}
