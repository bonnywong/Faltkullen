package com.mygdx.game;

import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.scenes.scene2d.ui.Tree.Node;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import faltkullen.Leader;

/**
 * Created by Anton on 2015-08-24.
 */
public class OrganogramUnder extends WidgetGroup {
    private Label selection;
    private Skin skin;

    private Leader selectedLeader;
    private Node selectedNode;
    private TextField nameField;
    private TextButton addButton;
    private TextButton removeButton;

    public OrganogramGroup organogram;

    public OrganogramUnder(Skin sk) {
        super();
        skin = sk;
        Label l = new Label("Currently Selected : Nothing", skin, "black");
        l.setPosition(0, 175);
        l.setSize(200, 25);
        addActor(l);
        selection = l;

        l = new Label("Name : ", skin, "black");
        l.setPosition(0, 150);
        l.setSize(50, 25);
        addActor(l);

        final TextField tf = new TextField("", skin);
        tf.setPosition(50, 150);
        tf.setSize(150, 25);
        tf.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor){
                if(selectedLeader != null){
                    selectedLeader.name = tf.getText();
                    TextButton tb = (TextButton)selectedNode.getActor();
                    if(tb != null){
                        tb.setText(tf.getText());
                    }
                    selection.setText("Currently Selected : " + tf.getText());
                }
            }
        });
        addActor(tf);
        nameField = tf;

        addButton = new TextButton("Add Leader", skin, "button");
        addButton.setPosition(15, 50);
        addButton.setSize(85, 25);
        addButton.addListener(new ChangeListener(){
            @Override
            public void changed(ChangeEvent event, Actor actor){
                if(organogram != null && selectedNode != null){
                    Leader l = new Leader(0, false);
                    selectedLeader.commands.add(l);
                    l.commandedBy = selectedLeader;
                    organogram.createNode(selectedNode, l);
                }
            }
        });
        addActor(addButton);

        removeButton = new TextButton("Remove this Leader", skin, "button");
        removeButton.setPosition(105, 50);
        removeButton.setSize(145, 25);
        removeButton.addListener(new ChangeListener(){
            @Override
            public void changed(ChangeEvent event, Actor actor){
                System.out.println("Removal begun");
                if(organogram != null && selectedNode != null){
                    organogram.removeNode(selectedNode, selectedLeader);
                }
            }
        });
    }

    public void leaderSelected(Leader l, Node n) {
        selection.setText("Currently Selected : " + l.name);
        selectedLeader = l;
        selectedNode = n;
        nameField.setText(l.name);

        if(l.commandedBy == null){
            removeButton.remove();
        }
        else if(removeButton.getParent() != this){
            addActor(removeButton);
        }
    }
}
