package faltkullen;

import java.util.ArrayList;

/**
 * A vehicle.
 */
public class Vehicle extends Unit {
    public int vehicleAccuracyBase;
    public int moveSpeed;

    public Unit target;
    public Squad inSquad;
    private Weapon weapon;

    public Vehicle(int dmg, int acc, int mor, int vehAccBase, int sensorRange) {
        weapon = new Weapon(dmg, acc);
        armor = new Armor(Armor.VEHICLE);
        morale = mor;
        this.vehicleAccuracyBase = vehAccBase;
    }

    public Vehicle(Settings s) {
        //attributes.get(0) Ã¤r DamageAttribute
        //attributes.get(1) Ã¤r AccuracyAttribute
        //attributes.get(2) Ã¤r ProtectionAttribute
        weapon = new Weapon(s);
        armor = new Armor(Armor.VEHICLE, s.getAttribute("Protection").current);
        morale = s.getAttribute("Morale").current;
        sensorRange = s.getAttribute("Sensor Range").current;
        moveSpeed = s.getAttribute("Move speed").current;
        vehicleAccuracyBase = s.getAttribute("Accuracy").current;
    }

    public int getAccuracy() {
        return (morale * vehicleAccuracyBase) / 100;
    }

    public int effAcc(int vAccB, int mor) {
        int vEffAcc = vAccB - mor;
        if (vEffAcc < 10) {
            vEffAcc = 10;
        }
        return vAccB;
    }

    public boolean fireAt(Unit target) {
        return weapon.fireAt(this, target);
    }

    public void hit(int dmg, Weapon w) {
        int finalDamageTaken = dmg - armor.getProtection(w);
        if (finalDamageTaken < 0) {
            finalDamageTaken = 0;
        }
        health -= finalDamageTaken;
        if (health <= 0) {
            System.out.println("Vehicle with ID " + id + " died!");
            alive = false;
        }
    }

    /*Finner avstånde mellan denna soldat och en fiendesoldat*/
    public int distanceToEnemy(Unit enemy) {
        double distance = getDistance((int) enemy.getX(), (int) enemy.getY());
        return (int) distance; //Kastar om  double till int.
    }

    /*Skannar av sin omgivning.*/
    public ArrayList<Unit> detectEnemy(ArrayList<Unit> enemyList) {
        ArrayList<Unit> detectedEnemies = new ArrayList<Unit>();
        for (int i = 0; i < enemyList.size(); i++) {
            if (distanceToEnemy(enemyList.get(i)) < sensorRange) {

                /*Enemy in range. Add to detected list? Add to shooting list? */
                /*Om soldaten inte har blivit upptäckt.*/
                if (!enemyList.get(i).getDetected()) {

                    enemyList.get(i).setDetected(true);
                    detectedEnemies.add(enemyList.get(i)); //Lägg till soldaten i listan detectedSoldiers
                    inSquad.inArmy.detectedEnemies.add(enemyList.get(i));

                } else {
                    /*Soldaten redan upptäckt sedan tidigare. Vi kan strunta i soldaten. */
                }

            } else {
                /*Enemy not in range*/
                enemyList.get(i).setDetected(false);
            }
        }
        return detectedEnemies;
    }

}
