package faltkullen;

import java.util.ArrayList;
import java.util.Random;

/**
 * Created by Anton on 2015-02-19.
 */
public class Group {
    public int initialSize = 10;
    public ArrayList<Unit> members = new ArrayList<Unit>();
    public Position startPosition;
    public Leader groupLeader;
    public boolean inCombat = false;
    public TestOfMap map;
    public Unit type; //The type of unit this Group hosts

    public String name;

    public Group(int is){
        initialSize = is;
    }

    public Group(Group g){
        initialSize = g.initialSize;
        type = g.type;
        startPosition = g.startPosition;
    }

    public Army army;

    /* Method Name : simpleMove
     * Parameters : Position p that represents where we want people to move
     * Returns : Nothing
     * Description:
     * This method is used as a baseline for creating more advanced movement methods.
     * This method essentially orders all members to move towards position <p> at the same time.
     */
    public void simpleMove(Position p){
        for(Unit u : members){
            u.advanceTowards(p);
        }
    }

    /**
     * Method Name : advanceTowards
     * Parameters : Position p that represents where we should move towards
     * Returns : Nothing
     * Description:
     * If this Group is in combat, it will attempt to fight
     * If this Group is not in combat, it will move towards p
     */
    public void advanceTowards(Position p){
        for(Unit u : members){
            u.update();
        }
        if(inCombat){
            ArrayList<Unit> detectedEnemies = new ArrayList<Unit>();
            for (Unit u : members) {
                ArrayList<Unit> enemiesInRange = map.getEnemiesWithinRange(u, u.sensorRange);
                for (Unit enemy : enemiesInRange) {
                    if (!enemy.getDetected()) {
                        enemy.setDetected(true);
                        detectedEnemies.add(enemy);
                        army.detectedEnemies.add(enemy);
                    }
                }
            }
            if (detectedEnemies.size() > 0) {
                attack(detectedEnemies);
            }
            else if(army.detectedEnemies.size() > 0){
                attack(army.detectedEnemies);
            }
            else{
                inCombat = false;
            }
        }
        else{
            simpleMove(p);
            ArrayList<Unit> detectedEnemies = new ArrayList<Unit>();
            for (Unit u : members) {
                ArrayList<Unit> enemiesInRange = map.getEnemiesWithinRange(u, u.sensorRange);
                for (Unit enemy : enemiesInRange) {
                    if (!enemy.getDetected()) {
                        enemy.setDetected(true);
                        detectedEnemies.add(enemy);
                        army.detectedEnemies.add(enemy);
                    }
                }
            }
            if (detectedEnemies.size() > 0) {
                attack(detectedEnemies);
            }
            else if(army.detectedEnemies.size() > 0){
                attack(army.detectedEnemies);
            }
            else{
                inCombat = false;
            }
        }
    }

    /**
     * Method Name : attack
     * Parameters : An array of Units belonging to the enemy
     * Returns : Nothing
     * Description:
     * This method will order every member of this Group to fire against Units belonging to the enemy (in the parameter).
     * The group will attempt to spread out its fire over as many targets as possible.
     * First, it will assign targets as long as there is a target in range.
     * Secondly, if there is not a non-assigned target in range, it will assign fire to a assigned target.
     * Thirdly, if there is not a non-assigned target in range, a member will move towards the closest enemy.
     */
    public void attack(ArrayList<Unit> enemies){
        inCombat = true;
        ArrayList<Unit> toBeAssigned = new ArrayList<Unit>(enemies);
        ArrayList<Unit> assigned = new ArrayList<Unit>();
        ArrayList<Unit> assigned2 = new ArrayList<Unit>();
        boolean standby = groupLeader.goal instanceof Standby;
        for(Unit m : members){
            Weapon w = m.getWeapon();
            boolean foundTarget = false;

            double shortest = 0.0;
            Unit closest = null;

            for(int a=0;a<enemies.size();a++){
                Unit enemy = enemies.get(a);
                double distance = m.getPosition().distance(enemy.getPosition());
                if(closest == null){
                    shortest = distance;
                    closest = enemy;
                }
                else if(shortest > distance){
                    shortest = distance;
                    closest = enemy;
                }
            }
            moveOrder++;
            //Is this member too intimidated by the enemy's proximity? In that case, its feared and will start to run towards the starting position
            if((shortest < m.fearRadius || m.feared) && !groupLeader.isAggressive){
                m.feared = true;
                m.advanceTowards(startPosition);
                continue;
            }

            for(int a=0;a<toBeAssigned.size();a++){
                Unit enemy = toBeAssigned.get(a);
                if(m.getPosition().distance(enemy.getPosition()) <= w.getRange()){
                    if(groupLeader.isAggressive && !enemy.isDead("attack")){
                        m.advanceTowards(enemy.getPosition());
                        m.movingFireAt(enemy);
                    }
                    else {
                        boolean hit = m.fireAt(enemy);
                        if(standby){
                            //System.out.println("Standby fires");
                            if(hit){
                                //System.out.println("Standby hits");
                            }
                        }
                    }
                    toBeAssigned.remove(a);
                    assigned.add(enemy);
                    foundTarget = true;
                    break;
                }
            }
            if(foundTarget){
                continue;
            }
            for(int a=0;a<assigned.size();a++){
                Unit enemy = assigned.get(a);
                if(m.getPosition().distance(enemy.getPosition()) <= w.getRange()){
                    if(groupLeader.isAggressive && !enemy.isDead("attack")){
                        m.advanceTowards(enemy.getPosition());
                        m.movingFireAt(enemy);
                    }
                    else {
                        boolean hit = m.fireAt(enemy);
                        if(standby){
                            //System.out.println("Standby fires");
                            if(hit){
                                //System.out.println("Standby hits");
                            }
                        }
                    }
                    assigned.remove(a);
                    assigned2.add(enemy);
                    foundTarget = true;
                    if(assigned.size() == 0){
                        assigned = assigned2;
                        assigned2 = new ArrayList<Unit>();
                    }
                    break;
                }
            }
            if(foundTarget){
                continue;
            }

            if(closest != null) {
                m.advanceTowards(closest.getPosition());
            }
            else{
                m.advanceTowards(groupLeader.goal.position);
            }
        }
    }

    public int moveOrder = 0;

    /**
     * Method Name : populate
     * Parameters:
     * TestOfMap map, the map that we should place this group inside
     * Position at, where the group is to be populated
     * Unit type, what type of unit to populate into this group
     * Returns : Nothing
     * Description:
     * When this method is called, this Group generates initialSize units of <type> into <map>.
     */
    public void populate(TestOfMap m){
        map = m;
        Random rand = new Random();
        for(int a=0;a<initialSize;a++){
            Unit u = type.clone();
            u.map = m;
            u.id = army.getNextID();
            army.units.add(u);
            u.team = army.team;

            //Set a new position for the new unit
            Position p = new Position(startPosition.x, startPosition.y);
            double randomDegree = rand.nextInt(360); //A random angle in degrees (0 and 360 is the same, and 360 is excluded)
            double randomDistance = rand.nextInt(10);
            double randomAngle = (Math.PI / 180) * randomDegree;
            p.x += Math.cos(randomAngle) * randomDistance;
            p.y += Math.sin(randomAngle) * randomDistance;
            u.setPosition(p);

            MapSector sector = m.getSectorFromPoint(p);
            sector.addToSector(u);
            u.containedIn = sector;
            members.add(u);
            u.group = this;
        }
    }

    /*
     * Method Name : hasGroundUnitWithin
     * Parameters:
     * Position p : The position to search
     * double radius : A radius that combined with a Position becomes a circle
     * Returns: A boolean that represents whether or not this squad has a Soldier within <radius> range of Position
     *
     * Description:
     * Goes through all Units in this Group and returns true if at least one of them are within <radius> range of <p>
     * Otherwise false
     */
    public boolean hasGroundUnitWithin(Position p, double radius){
        for(Unit u : members){
            if(u.getPosition().distance(p) <= radius){
                return true;
            }
        }
        return false;
    }

    /*
     * Method Name : getReadiness
     * Parameters : None
     * Returns : The Groups combat readiness, measured as a double from 0.0 to 5.0, where 5.0 is perfect condition
     *
     * Description:
     * Goes through certain checks to determine this Groups combat readiness and returns that readiness in the form of a double.
     * Things checked:
     *      Current member size : Has the Group lost a lot of members? More lost members = less readiness
     */
    public double getReadiness(){
        double memberRatio = (double)members.size() / (double)initialSize;
        return 5.0 * memberRatio * memberRatio;
    }

    /*
     * Method Name : combatCheck
     * Parameters : None
     * Returns : Nothing
     *
     * Description:
     * This method checks if this Group can sense nearby enemies, and if they can, they attack.
     */
    public void combatCheck() {
        ArrayList<Unit> detectedEnemies = new ArrayList<Unit>();
        for (Unit u : members) {
            ArrayList<Unit> enemiesInRange = map.getEnemiesWithinRange(u, u.sensorRange);
            for (Unit enemy : enemiesInRange) {
                if (!enemy.getDetected()) {
                    enemy.setDetected(true);
                    detectedEnemies.add(enemy);
                    army.detectedEnemies.add(enemy);
                }
            }
        }
        if (detectedEnemies.size() > 0) {
            System.out.println("Standby attacks");
            attack(detectedEnemies);
        } else if (army.detectedEnemies.size() > 0) {
            System.out.println("Standby attacks");
            attack(army.detectedEnemies);
        } else {
            inCombat = false;
        }
    }
}
