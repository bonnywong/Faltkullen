package faltkullen;

/**
 * Created by Anton on 2015-04-13.
 * This class is intended to represent a particular message sent between one leader to another.
 * A general uses this to issue commands to lesser officers, and lesser officers use this to report back.
 */
public class LeaderCommunication {
    public int report; //placeholder
    public Goal goal; //The goal-command being sent
    public Leader to; //Who is supposed to recieve the communication?
    public Leader from; //Who is the communication from?
}
