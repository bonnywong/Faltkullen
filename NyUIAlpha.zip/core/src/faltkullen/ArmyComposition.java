package faltkullen;

import java.util.ArrayList;

/**
 * Created by Anton on 2015-08-24.
 */
public class ArmyComposition {
    public ArrayList<Group> groups;
    public Leader leader;
    public ArmyComposition(){
        groups = new ArrayList<Group>();
    }
}
