package faltkullen;

import java.util.ArrayList;

import com.badlogic.gdx.utils.Array;
import faltkullen.Goal;

/**
 * Created by Anton on 2015-02-19.
 */
public class Leader implements Cloneable{
    public int communicationDelayUp = 5; //The delay between materializing a Decision and sending it upwards in the chain of command
    public int communicationDelayDown = 1; //The delay between materializing a Decision and sending it downward in the chain of command
        //This delay is for EACH lesser officer, so 10 officers with delay 1 means officer 1 will recieve it after 1 second, and officer 10 will recieve it after 10 seconds
    public int delayCounter = 0; //As there is delay, this variable represents how many seconds longer the delay must last
    public int decisionTime = 0; //The amount of seconds it takes for this Leader to make a Decision
    private double retreatAt = 3.0; //The Entropy value at which this Leader calls for a Retreat
    public boolean retreating = false;

    public Goal goal;   //The Goal of this Leader
    public boolean inCombat = false; //Is true if one of the Squads this Leader is commanding is in combat
    public ArrayList<Leader> commands; //A list of Leaders that this Leader has command over
    public Unit leaderInField; //Is this Leader on the field? In that case this is not null, and represents this Leader
    public Group inGroup; //If this Leader is on the field, this is the Group that its a part of
    public Leader replacement; //If the Leader is on the field and dies, this template Leader replaces the Leader inside the Leaders own squad.
    public Leader commandedBy; //If the Leader is commanded by another Leader, this is that leader
    public Leader verificationLeader; //This Leader sends verificationLeader to verify whether or not the Goal has been completed
        //If null, then itself should verify
    public boolean setInMotion = false; //Has this Leader commanded other Leaders to do action that should complete the Goal?
        //In other words, has the Leader ordered other Leaders already and is meerly waiting for them to respond?

    public ArrayList<LeaderCommunication> communications = new ArrayList<LeaderCommunication>();

    public boolean isAggressive = false;

    public String name = "Unnamed Leader";

    public Leader(double ret, boolean aggro){
        retreatAt = ret;
        isAggressive = aggro;
        commands = new ArrayList<Leader>();
    }

    public Leader(Leader template, TestOfMap map, Army army, double ret, boolean aggro){
        retreatAt = ret;
        isAggressive = aggro;
        commands = new ArrayList<Leader>();
        ArrayList<Leader> templateCommands = template.getCommand();
        if(templateCommands.size() > 0) {
            for (Leader under : templateCommands) {
                if (under == null) {
                    System.out.println("under is null");
                }
                if (map == null) {
                    System.out.println("map is null");
                }
                if (army == null) {
                    System.out.println("army is null");
                }
                Leader newUnder = new Leader(under, map, army, ret, aggro);
                newUnder.commandedBy = this;
                commands.add(newUnder);
            }
        }
        if(template.inGroup != null){
            inGroup = new Group(template.inGroup);
            inGroup.army = army;
            inGroup.populate(map);
            inGroup.groupLeader = this;
            leaderInField = inGroup.members.get(0);
        }
    }

    public synchronized ArrayList<Leader> getCommand(){
        return new ArrayList<Leader>(commands);
    }

    /* Method Name:
     * Parameters:
     * Position p : The position to search
     * float radius : A radius that combined with a Position becomes a circle
     * Returns : A boolean that represents whether or not this Leader has a ground-based unit within <radius> range of <p>
     *
     * Description:
     * This method essentially goes through all ground-based Units under this Leader and returns true the moment it finds something that is within
     * <radius> range of <p>. This method is slow if called high up in the chain of command without any unit fitting the searched criteria.
     */
    public boolean hasGroundUnitWithin(Position p, double radius){
        for(int a = 0;a<commands.size();a++){
            if(commands.get(a).hasGroundUnitWithin(p, radius)){
                return true;
            }
        }
        if(leaderInField != null){
            return inGroup.hasGroundUnitWithin(p, radius);
        }
        return false;
    }

    public void giveOrder(){
        for(int a=0;a<commands.size();a++){
            commands.get(a).takeOrder(goal);
        }
    }

    public void takeOrder(Goal g){
        goal = g;
        setInMotion = false;
    }

    public void reportSuccess(Leader l){

    }

    public void recieveCommunication(LeaderCommunication comm){
        //System.out.println("Communication recieved");
        if(comm.goal != null && commandedBy == comm.from){
            //System.out.println("Communication accepted");
            takeOrder(comm.goal);
        }
    }

    public int thoughtCounter = 0;
    public boolean extraDelay = false;

    public void think(){
        //Have we set things in motion?
        if(!setInMotion && commands.size() > 0 && goal != null){
            //No, so we should set a verificationLeader
            //For simplicity, we assert commands.get(0) as the verificationLeader
            verificationLeader = commands.get(0);
            //For each of those this Leader commands, create a LeaderCommunication object and insert it into communications
            for(int a=0;a<commands.size();a++){
                LeaderCommunication comm = new LeaderCommunication();
                comm.from = this;
                comm.to = commands.get(a);
                comm.goal = goal;
                communications.add(comm);
            }
            delayCounter = communicationDelayDown;
            if(extraDelay){
                delayCounter += commands.size();
            }
            //giveOrder();
            setInMotion = true;
        }
        if(communications.size () > 0){
            delayCounter--;
            while(delayCounter <= 0) {
                LeaderCommunication comm = communications.remove(0);
                comm.to.recieveCommunication(comm);
                if(communications.size() > 0) {
                    if (communications.get(0).goal != null) {
                        delayCounter = communicationDelayDown;
                        if(extraDelay){
                            delayCounter += commands.size();
                        }
                    } else {
                        delayCounter = communicationDelayUp;
                    }
                }
                else{
                    delayCounter = 1;
                }
            }
        }
        if(goal == null && inGroup != null){
            goal = new Standby();
        }
        thoughtCounter++;
        //System.out.println("We get here, for the " + thoughtCounter + " time");
        //If we don't have a goal, dont do anything
        if(inGroup != null && goal != null) {
            //System.out.println("Move soldier!");
            goal.action(inGroup);
            //inGroup.advanceTowards(goal.position);

            //Should we retreat?
            if (inGroup.getReadiness() <= retreatAt && !retreating) {
                //System.out.println("retreating with readiness " + inGroup.getReadiness() + ", our limit being " + retreatAt);
                //Yes, the Leader thinks they should retreat
                retreating = true;
                goal = new RetreatTo(inGroup.startPosition, 5.0);
            }

            //Have we completed our goal?
            if (goal.complete(this)) {
                //We have, is there a follow-up goal?
                if (goal.condition != null) {
                    //Yes, check if we meet the condition
                    if (goal.condition.check(inGroup)) {
                        //We meet the condition, so set our current goal to continueGoal
                        goal = goal.continueGoal;
                    } else {
                        //We do not meet the condition, so set our current goal to breakGoal
                        goal = goal.breakGoal;
                    }
                }
            }
        }
        for(Leader under : commands){
            under.think();
        }
    }

    public Leader clone(){
        try{
            Leader l = (Leader)super.clone();
            l.commands = new ArrayList<Leader>(commands);
            return l;
        }
        catch(CloneNotSupportedException e){
            return null;
        }
    }

    public Array<Leader> getLeaderList(){
        Array<Leader> ret = new Array<Leader>();
        ret.add(this);
        for(Leader l : commands){
            ret.addAll(l.getLeaderList());
        }
        return ret;
    }

    public String toString(){
        return name;
    }
}
