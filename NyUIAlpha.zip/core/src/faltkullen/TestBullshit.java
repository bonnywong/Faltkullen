package faltkullen;

/**
 * Created by Anton on 2015-02-19.
 */
public class TestBullshit {
    Unit u;
    Goal g;
    Leader l;
    Group gro;
    Soldier sold;
}
