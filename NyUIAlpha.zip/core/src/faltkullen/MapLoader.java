//package faltkullen;
//public class MapLoader{
//  public static Map loadMap(){
//    Map aMap = new Map();
//    return aMap;
//  }
//}